@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Please install Node.js 24 LTS from https://nodejs.org and run this again. & pause & exit /b 1)
if not exist .env copy .env.example .env >nul
start "" /min cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:5100"
echo Keep this window open while you use the site. Press Ctrl+C to stop.
node server.js
pause
