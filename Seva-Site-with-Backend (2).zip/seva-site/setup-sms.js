// Fast2SMS setup helper: saves your key into .env and sends ONE test SMS to your own number.
const fs = require('fs'), path = require('path'), readline = require('readline');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const queue = []; let waiter = null;
rl.on('line', l => { if (waiter) { const w = waiter; waiter = null; w(l.trim()); } else queue.push(l.trim()); });
rl.on('close', () => { if (waiter) { const w = waiter; waiter = null; w(''); } });
const ask = q => { process.stdout.write(q); return new Promise(r => { if (queue.length) r(queue.shift()); else waiter = r; }); };
(async () => {
  console.log('\n=== Fast2SMS setup (Shri Sai Seva One) ===\n');
  console.log('Get your key: Fast2SMS > Dev API > copy the API key (keep it private).\n');
  const key = await ask('Paste your Fast2SMS API key: ');
  if (key.length < 20) { console.log('\nThat key looks too short. Copy the whole key from Dev API and try again.'); return rl.close(); }
  const mob = await ask('Your own 10-digit mobile number (for one test SMS): ');
  if (!/^[6-9]\d{9}$/.test(mob)) { console.log('\nEnter a valid 10-digit Indian mobile number and try again.'); return rl.close(); }
  const envPath = path.join(__dirname, '.env');
  let t = fs.readFileSync(fs.existsSync(envPath) ? envPath : path.join(__dirname, '.env.example'), 'utf8');
  const set = (k, v) => { const re = new RegExp('^' + k + '=.*$', 'm'); t = re.test(t) ? t.replace(re, () => k + '=' + v) : t + '\n' + k + '=' + v + '\n'; };
  set('SMS_PROVIDER', 'fast2sms'); set('FAST2SMS_API_KEY', key); set('FAST2SMS_OTP_ROUTE', 'q'); set('FAST2SMS_NOTIFY_ROUTE', 'q');
  fs.writeFileSync(envPath, t);
  console.log('\nSaved your settings to .env');
  console.log('Sending a test SMS (this uses one SMS from your Fast2SMS balance)...');
  try {
    const r = await fetch(process.env.FAST2SMS_URL || 'https://www.fast2sms.com/dev/bulkV2', { method: 'POST',
      headers: { authorization: key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ route: 'q', message: 'Shri Sai Seva One: test message. Your SMS setup works.', language: 'english', flash: 0, numbers: mob }) });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.return === true) console.log(`\nSUCCESS: test SMS sent to ${mob}. Now double-click start.bat.`);
    else console.log('\nFast2SMS said:', JSON.stringify(j), '\n\nFix that (usually the key or the account balance), then run setup-sms.bat again.');
  } catch (e) { console.log('\nCould not reach Fast2SMS. Check your internet connection and try again.'); }
  rl.close();
})();
